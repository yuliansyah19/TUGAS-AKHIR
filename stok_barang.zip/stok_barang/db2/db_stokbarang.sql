-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Des 2022 pada 12.29
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_stokbarang`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('sp2b6kqsvgf6jsqs2afmdksphb2lvulh', '::1', 1670420975, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432303937353b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('nos85ilbnma5k05bf3n9rgmc9tinp4uf', '::1', 1670420914, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432303931343b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('ciakbnu0pahfrn2438rq8i86q5uargha', '::1', 1670421297, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432313239373b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('dakbjh1vsin846bo6uclhsurm7f61pcm', '::1', 1670420975, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432303937353b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('pore50d8k59d7agova130jjlsj2gt9oq', '::1', 1670421869, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432313836393b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('dt0rmk9260dglhmiqh8s8adrrh8dqa2v', '::1', 1670422172, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432323137323b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('as7evp099dpgm1mpv9qvun4lnltegsui', '::1', 1670422679, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432323637393b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('c3jcgkt50j64djs6rrf0k1f0335j44td', '::1', 1670422987, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432323938373b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('4po9nnirnuamuj2b1340cvl80do5ugoc', '::1', 1670423298, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432333239383b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('rs33uioi78gcf85bb13tjd7nretd1ett', '::1', 1670429558, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432393535383b5573657249447c733a313a2231223b557365727c733a32323a2241686d6164204477692059756c69616e737961682049223b6c6576656c7c733a353a2261646d696e223b666f746f7c733a31383a22666f746f313635323639323537332e706e67223b),
('ulmjtfrtbovfm3ausnphpq8ii6p1jc9p', '::1', 1670429558, 0x5f5f63695f6c6173745f726567656e65726174657c693a313637303432393535383b);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `kode_barang` varchar(6) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `harga` double NOT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_barang`
--

INSERT INTO `tbl_barang` (`kode_barang`, `nama_barang`, `brand`, `stok`, `harga`, `active`) VALUES
('ABOSE', 'BOSE MINI SPEAKER PORTABLE', 'BOSE', 5, 700000, 'N'),
('AMITO', 'MITO AIR FRYER AF1', 'MITO', 4, 999000, 'Y'),
('ASONY', 'SONY MIC WIRELESS PORTABLE', 'SONY', 5, 250000, 'Y'),
('CANON', 'SPEAKER AKTIF ', 'PIONEER', 0, 500000, 'Y'),
('MATRX', 'MATRIX SET TOP BOX APPLE HD', 'MATRIX', 4, 295000, 'Y'),
('PANSC', 'PANASONIC MIXER', 'PANASONIC', 3, 500000, 'Y'),
('PHLPS', 'BLENDER PHILIPS HR 2115', 'PHILIPS', 10, 799000, 'Y'),
('PIONR', 'SPEAKER AKTIF ', 'PIONEER', 14, 500000, 'Y'),
('PLTRN', 'POLITRON SPEAKER AKTIF', 'POLITRON', 10, 300000, 'Y'),
('SHARP', 'SHARP KIPAS ANGIN TURBO', 'SHARP', 6, 700000, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_pembelian`
--

CREATE TABLE `tbl_detail_pembelian` (
  `id_pembelian` varchar(20) NOT NULL,
  `id_barang` varchar(6) NOT NULL,
  `qty` smallint(6) NOT NULL,
  `harga` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_detail_pembelian`
--

INSERT INTO `tbl_detail_pembelian` (`id_pembelian`, `id_barang`, `qty`, `harga`) VALUES
('ID1669980847', 'PIONR', 10, 150000),
('ID1669980890', 'MATRX', 2, 190000),
('ID1670422823', 'PLTRN', 10, 150000);

--
-- Trigger `tbl_detail_pembelian`
--
DELIMITER $$
CREATE TRIGGER `pembelian_barang` AFTER INSERT ON `tbl_detail_pembelian` FOR EACH ROW BEGIN
	UPDATE tbl_barang b SET b.stok = b.stok + new.qty
    WHERE b.kode_barang = new.id_barang;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_pembelian` AFTER DELETE ON `tbl_detail_pembelian` FOR EACH ROW BEGIN
	UPDATE tbl_barang b SET b.stok = b.stok - old.qty
    WHERE b.kode_barang = old.id_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_penjualan`
--

CREATE TABLE `tbl_detail_penjualan` (
  `id_penjualan` varchar(20) NOT NULL,
  `id_barang` varchar(6) NOT NULL,
  `qty` smallint(6) NOT NULL,
  `harga` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_detail_penjualan`
--

INSERT INTO `tbl_detail_penjualan` (`id_penjualan`, `id_barang`, `qty`, `harga`) VALUES
('ID1669980059', 'PHLPS', 2, 799000),
('ID1669980495', 'PLTRN', 2, 300000),
('ID1670421398', 'PLTRN', 2, 300000);

--
-- Trigger `tbl_detail_penjualan`
--
DELIMITER $$
CREATE TRIGGER `penjualan_barang` AFTER INSERT ON `tbl_detail_penjualan` FOR EACH ROW BEGIN
	UPDATE tbl_barang b SET b.stok = b.stok - new.qty
    WHERE b.kode_barang = new.id_barang;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_penjualan` AFTER DELETE ON `tbl_detail_penjualan` FOR EACH ROW BEGIN
	UPDATE tbl_barang b SET b.stok = b.stok + old.qty
    WHERE b.kode_barang = old.id_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pembelian`
--

CREATE TABLE `tbl_pembelian` (
  `id_pembelian` varchar(20) NOT NULL,
  `tgl_pembelian` date NOT NULL,
  `id_supplier` varchar(15) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_pembelian`
--

INSERT INTO `tbl_pembelian` (`id_pembelian`, `tgl_pembelian`, `id_supplier`, `id_user`) VALUES
('ID1669980847', '2022-12-02', 'ID1669978519', 1),
('ID1669980890', '2022-12-02', 'ID1669978519', 1),
('ID1670422823', '2022-12-07', 'ID1669978519', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_penjualan`
--

CREATE TABLE `tbl_penjualan` (
  `id_penjualan` varchar(20) NOT NULL,
  `nama_pembeli` varchar(30) NOT NULL,
  `tgl_penjualan` date NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_penjualan`
--

INSERT INTO `tbl_penjualan` (`id_penjualan`, `nama_pembeli`, `tgl_penjualan`, `id_user`) VALUES
('ID1669980059', 'WIYONO', '2022-12-02', 1),
('ID1669980495', 'YANTI', '2022-12-02', 1),
('ID1670421398', 'wahyudi', '2022-12-07', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_supplier`
--

CREATE TABLE `tbl_supplier` (
  `id_supplier` varchar(15) NOT NULL,
  `nama_supplier` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `telp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id_supplier`, `nama_supplier`, `alamat`, `telp`) VALUES
('ID1669978519', 'PT Jojo Optima Solusindo', 'Jl. Arteri Pegangsaan Dua, Kelapa Gading', '085771695');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `hp` varchar(20) NOT NULL,
  `foto` varchar(50) NOT NULL DEFAULT 'default.jpg',
  `level` enum('admin','pegawai') NOT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `fullname`, `password`, `alamat`, `hp`, `foto`, `level`, `active`, `last_login`) VALUES
(1, 'Julian', 'Ahmad Dwi Yuliansyah I', '$2y$08$BO41OJFfhPPPzjKdWw2I6OyUElK1mkD43UVt1ss6J1xrVUExC1lRy', 'Pulau Sabira', '082114504970', 'foto1652692573.png', 'admin', 'Y', '2022-12-07 23:12:38'),
(9, 'shafiera', 'Shafiera El\'Yasha', '$2y$10$1RpKKMgGiH5rzPH2sRVEhe5lP9XwlkU6/X5GQmgUXwRYeMj.GFqYS', 'Jl.Berbah Sleman no 17', '08133457212', 'default.jpg', 'pegawai', 'Y', '2022-12-07 13:50:41');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indeks untuk tabel `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indeks untuk tabel `tbl_pembelian`
--
ALTER TABLE `tbl_pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indeks untuk tabel `tbl_penjualan`
--
ALTER TABLE `tbl_penjualan`
  ADD PRIMARY KEY (`id_penjualan`);

--
-- Indeks untuk tabel `tbl_supplier`
--
ALTER TABLE `tbl_supplier`
  ADD PRIMARY KEY (`id_supplier`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
